import logging
import time

from django.views.generic.edit import UpdateView, CreateView
from django.views.generic.detail import DetailView
from django.shortcuts import render, get_object_or_404

from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response

from support.forms import ProfileForm
from support.models import Profile
from support.serializers import ProfileSerializer

@api_view(['GET', 'POST'])
def profile_list(request):
    """
    List all profiles, or create a new profile.
    """
    if request.method == 'GET':
        profiles = Profile.objects.all()
        serializer = ProfileSerializer(profiles, many=True)
        return Response(serializer.data,
                        status=status.HTTP_200_OK)
        
    elif request.method == 'POST':
        INFO = request.POST.copy()
        if request.POST.get('nickname'):
            INFO['username'] = request.POST.get('nickname')
        if request.POST.get('first'):
            INFO['first_name'] = request.POST.get('first')
        if request.POST.get('last'):
            INFO['last_name'] = request.POST.get('last')
        serializer = ProfileSerializer(data=INFO)
        if serializer.is_valid():
            serializer.save()
            return Response({'error': 'false',
                             'time': time.time(),
                             'userid': serializer.data['id'],
                             },
                            status=status.HTTP_201_CREATED)
    return Response({'error': 'true',
                     'time': time.time(),
                     'msg': serializer.errors,},
                    status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET', 'PUT', 'DELETE'])
def profile_detail(request, pk):
    """
    Retrieve, update or delete a profile instance.
    """
    try:
        profile = Profile.objects.get(pk=pk)
    except Profile.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)
        
    if request.method == 'GET':
        serializer = ProfileSerializer(profile)
        return Response(serializer.data,
                        status=status.HTTP_200_OK)

    elif request.method == 'PUT':
        INFO = request.DATA.copy()
        if request.DATA.get('nickname'):
            INFO['username'] = request.DATA.get('nickname')
        if request.DATA.get('first'):
            INFO['first_name'] = request.DATA.get('first')
        if request.DATA.get('last'):
            INFO['last_name'] = request.DATA.get('last')
        serializer = ProfileSerializer(profile, data=INFO)
        if serializer.is_valid():
            serializer.save()
            field_data = []
            for key, value in request.DATA.iteritems():
                field_data.append({'field': key,
                                   'value': value})
            if len(field_data) == 1:
                field_data = field_data[0]
            return Response(field_data,
                            status=status.HTTP_200_OK)
        
    elif request.method == 'DELETE':
        profile.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

    return Response({'error': 'true',
                     'time': time.time(),
                     'msg': serializer.errors,},
                    status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET'])
def profile_find(request):
    """
    Find a profile by nick_name
    """
    if request.method == 'GET':
        try:
            nick_name = request.GET['nickname']
            profile = Profile.objects.get(username=nick_name)
        except:
            return Response(status=status.HTTP_404_NOT_FOUND)

        serializer = ProfileSerializer(profile)
        return Response(serializer.data,
                        status=status.HTTP_200_OK)

@api_view(['POST'])
def battle_detail(request):
    """
    TODO
    """
    if request.method == 'POST':
        serializer = BattleSerializer(data=request.POST)
        if serializer.is_valid():
            serializer.save()
            return Response({'error': 'false',
                             'time': time.time(),
                             },
                            status=status.HTTP_201_CREATED)
    return Response({'error': 'true',
                     'time': time.time(),},
                    status=status.HTTP_400_BAD_REQUEST)
        
def profile_view(request):
    logging.debug("Request Type: {0}".format(request.method))
    if request.method == 'GET':
        profile = get_object_or_404(Profile, pk=id)
        return render(request, 'profile_detail.html', {
            'profile': profile,
        })

def new_profile(request):
    data = request.POST.copy()
    form = ProfileForm(data)
    if request.method == 'POST':
        profile = Profile.objects.create_profile(
            data['nick_name'],
            data['first_name'],
            data['last_name'],
            data['wins'],
            data['losses'],
            data['win_streak'],
            data['created'],
            data['last_seen']
        )
    return render(request, 'profile_create.html', {
        'form': form,
    })

def todo(request):
    """
    List all snippets, or create a new snippet.
    """
    if request.method == 'GET':
        profiles = Profile.objects.all()
        serializer = SnippetSerializer(snippets, many=True)
        return Response(serializer.data)
        
    elif request.method == 'POST':
        serializer = SnippetSerializer(data=request.DATA)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            
            
class ProfileCreateView(CreateView):
    """
    TODO
    """

    template_name = 'profile_create.html'
    model = Profile
    form_class = ProfileForm
    success_url = '/users'


class ProfileDetailView(DetailView):
    """
    TODO
    """

    model = Profile
    template_name = 'profile_detail.html'
    serializer_class = ProfileSerializer
