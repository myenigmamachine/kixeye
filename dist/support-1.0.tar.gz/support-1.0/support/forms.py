import logging
import time

from django import forms
from django.utils import html
from support.models import Profile

class ProfileForm(forms.ModelForm):
    wins = forms.IntegerField(initial=0, required=False)
    losses = forms.IntegerField(initial=0, required=False)
    win_streak = forms.IntegerField(initial=0, required=False)
    created = forms.DateTimeField(initial=time.time(), required=False)
    last_seen = forms.DateTimeField(initial=time.time(), required=False)

    class Meta:
        model = Profile
        fields = ['first_name', 'last_name', 'nick_name', 'wins', 'losses', 'win_streak', 'created', 'last_seen']
