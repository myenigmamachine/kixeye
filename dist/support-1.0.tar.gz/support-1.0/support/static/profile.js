function clear() {
    var nick_name = document.getElementById("id_nick_name");
    nick_name.value = "";
}
